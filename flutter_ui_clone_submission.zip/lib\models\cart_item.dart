import 'package:flutter/material.dart';
import 'product.dart';

class CartItem {
  final Product product;
  final String selectedSize;
  final Color selectedColor;
  int quantity;

  CartItem({
    required this.product,
    required this.selectedSize,
    required this.selectedColor,
    this.quantity = 1,
  });

  double get totalPrice => product.price * quantity;

  String get uniqueKey => '${product.id}_${selectedSize}_${selectedColor.toARGB32()}';
}
